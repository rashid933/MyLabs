package pakage1;

public class Employee {
    public long CalculateSalary(){
        return 30000;
    }
}

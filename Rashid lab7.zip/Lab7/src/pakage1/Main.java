package pakage1;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

Manager m = new Manager();
System.out.println("The bonus Salary of Manager:"+m.CalculateSalary());
Worker w = new Worker();
System.out.println("The bonus Salary of Worker:"+w.CalculateSalary());

    }
}
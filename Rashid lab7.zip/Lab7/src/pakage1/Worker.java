package pakage1;

public class Worker extends Employee{
    @Override
   public long CalculateSalary() {
        return super.CalculateSalary()*10000;
    }
}

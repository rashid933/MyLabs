package pakage1;

public class Manager extends Employee{
    @Override
   public long CalculateSalary() {
        return super.CalculateSalary()*20000;
    }
}

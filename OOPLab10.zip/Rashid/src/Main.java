

 abstract class  Animal{
 abstract void  makeSound();
void eat(){
System.out.println("The Animal is Eating.");
}
}
 class Dog extends Animal{
     void makeSound(){
         System.out.println("The Dog is barking bhobho!");
     }
     void eat(){
         System.out.println("The Dog is Eating");
     }
 }
 class Cat extends Animal{
     void makeSound(){
         System.out.println("The Cat is Making Sound miaow!");
     }
     void eat(){
         System.out.println("The Cat  is Eating");
     }
 }

        
        
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Animal dog=new Dog();
        Cat cat = new Cat();
        cat.eat();
        cat.makeSound();
        dog.eat();
        dog.makeSound();
    }
    
}

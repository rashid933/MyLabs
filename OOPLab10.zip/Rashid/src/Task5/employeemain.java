/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task5;

/**
 *
 * @author f24ari137
 */
public class employeemain {
    public static void main(String[] args){
        FullTimeEmployee ef=new FullTimeEmployee();
        PartTime pt=new PartTime();
        ef.Calculatesalary();
        ef.paytax();
        pt.Calculatesalary();
        pt.paytax();
    }
    
}

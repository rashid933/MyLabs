package Task5;

public abstract class Employee {
    String name;
    String id;
    abstract void Calculatesalary();
    
}

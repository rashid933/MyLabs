/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Task5;

/**
 *
 * @author f24ari137
 */
interface Taxpayer {
    void paytax();
}

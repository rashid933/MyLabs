/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task5;

/**
 *
 * @author f24ari137
 */
public class PartTime extends Employee implements Taxpayer {
     @Override
    public void Calculatesalary() {
        System.out.println("The part time Salary is 64");
    }
    @Override
   public void paytax(){
        System.out.println("Tax  is 3444");
    }
    
}

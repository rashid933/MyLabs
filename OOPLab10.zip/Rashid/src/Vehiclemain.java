/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author f24ari137
 */
public class Vehiclemain {
    public static void main(String[] arg){
        Rectangle r=new Rectangle();
       
        r.area();
        r.print();
    }
}

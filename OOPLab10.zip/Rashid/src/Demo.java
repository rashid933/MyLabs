/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author f24ari137
 */
public class Demo {
     public static void main(String[] args) {
        // TODO code application logic here
        Car car=new Car();
        Bike bike = new Bike();
        car.start();
        car.stop();
        bike.start();
        bike.stop();
    }
}

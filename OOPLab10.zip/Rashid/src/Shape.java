
public abstract class Shape {
    abstract double  area();
}
 interface Printable{
     void print();
 }

class Rectangle extends Shape implements Printable{
    double length=10;
    double width=10;
@Override
   public  double area(){
        return length*width;
    
    
}
    @Override
    public void print() {
      System.out.println("This is the  Area of Rectangle ");
    }
}

 
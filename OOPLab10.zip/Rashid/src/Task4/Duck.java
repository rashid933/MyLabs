package Task4;
public class Duck implements Flyable,Swimmable{
    public void fly(){
        System.out.println("The Duck is Flying");        
    }

    public void swim(){
        System.out.println("The is Swimming "); 
    } 
}


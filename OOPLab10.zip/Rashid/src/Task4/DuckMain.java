/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task4;

/**
 *
 * @author f24ari137
 */
public class DuckMain {
    public static void main(String[] arg){
        Duck duck =new Duck();
        duck.fly();
        duck.swim();
    }
    
}

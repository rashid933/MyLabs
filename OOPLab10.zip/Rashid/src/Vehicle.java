/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
public interface Vehicle {
    void start();
    void stop();
    
}
class Car implements Vehicle{
    public void start(){
        System.out.println("The car starts.");
    }
    public void stop(){
        System.out.println("The car stops.");
    }
}
class Bike implements Vehicle{
    
    public void start(){
        System.out.println("The Bike starts.");
    }
    public void stop(){
        System.out.println("The Bike stops.");
    }
}
 